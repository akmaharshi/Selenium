package CreditAccountType;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;

public class AddAccount {
	//WebDriver driver = new FirefoxDriver();
	 //@BeforeMethod
	  //public void beforeMethod() {
		 
		  
			//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
			//driver.manage().window().maximize();
	// }		
  @Test
  public void TestCase1() throws InterruptedException {
	  System.out.println("Testcase 1 Started");
	  System.out.println("Scenario- Add Account for Loan Process Credit- Started");
	    WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
		driver.manage().window().maximize();
	  driver.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys("user@lrv");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("rules");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='sub']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[1]/div/div/div[4]/div/div/div/div/div/div/div/span/a")).click();
		Thread.sleep(500);
		driver.findElement(By.linkText("AddAccount")).click();
	    Thread.sleep(500);
	    //System.out.print("Accountcreated");
	    Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='FirstName']")).sendKeys("mark");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='LastName']")).sendKeys("johnson");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='AccountNo']")).sendKeys("36542");
		Thread.sleep(500);
		new Select(driver.findElement(By.xpath(".//*[@id='TypeOfAccount']"))).selectByVisibleText("Credit");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='LoanAmount']")).sendKeys("2000");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/span/button")).click();
		Thread.sleep(500);
		System.out.println("Credit Account created");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div[2]/div/div/span/a")).click();
		Thread.sleep(500);
	    driver.findElement(By.linkText("Log off")).click();
	    driver.close();
	    driver.quit();
	    System.out.println("Scenario- Add Account for Loan Process Credit- Ended");
	    System.out.println("Testcase 1 Completed");
	    System.out.println(" ");
  }


  //@AfterMethod
  //public void afterMethod() {
	  //driver.close();
	  //driver.quit();
	  
  }

//}
