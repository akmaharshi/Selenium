package CreditAccountType;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class LoanProcessScenario2_ManagerApprove {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
		driver.manage().window().maximize();
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys("manager@lrv");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("rules");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='sub']")).click();
		Thread.sleep(500);
		driver.findElement(By.linkText("My Work")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[1]/div/div/div[5]/div/div/div/div/div/div/div/span/a")).click();
		//driver.manage().timeouts().wait(500);
		//driver.findElement(By.id("ManagerApproval")).sendKeys("Approve");
		//Thread.sleep(500);
		//new Select(driver.findElement(By.name("ManagerApproval"))).selectByVisibleText("Approve");
		//Thread.sleep(200);
		//driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/span/button")).click();
		//Thread.sleep(500);
		//driver.switchTo().frame("");
		
		// ERROR: Caught exception [ERROR: Unsupported command [selectFrame | PegaGadget2Ifr | ]]
	    //new Select(driver.findElement(By.id("ManagerApproval"))).selectByVisibleText("Approve");
	    //driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/span/button")).click();
	    driver.findElement(By.linkText("Log off")).click();
	    Thread.sleep(1000);
	    driver.close();
	    
		
		
		


	}

}
