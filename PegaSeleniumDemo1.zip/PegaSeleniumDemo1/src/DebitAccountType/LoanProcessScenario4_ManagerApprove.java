package DebitAccountType;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoanProcessScenario4_ManagerApprove {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
		driver.manage().window().maximize();
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys("manager@lrv");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("rules");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='sub']")).click();
		Thread.sleep(500);
		driver.findElement(By.linkText("My Work")).click();
		Thread.sleep(500);
		driver.findElement(By.linkText("A-67")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='ManagerApproval']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/span/button")).click();
		Thread.sleep(1000);
		driver.close();

	}

}
