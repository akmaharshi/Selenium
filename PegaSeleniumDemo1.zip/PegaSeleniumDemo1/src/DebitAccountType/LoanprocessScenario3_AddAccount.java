package DebitAccountType;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class LoanprocessScenario3_AddAccount {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
		    driver.manage().window().maximize();
		    Thread.sleep(300);
		    driver.findElement(By.xpath("//*[@id='txtUserID']")).sendKeys("user@lrv");
		    Thread.sleep(300);
		    driver.findElement(By.xpath("//*[@id='txtPassword']")).sendKeys("rules");
		    Thread.sleep(300);
		    driver.findElement(By.xpath(".//*[@id='sub']")).click();
		    Thread.sleep(300);
		    driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[1]/div/div/div[4]/div/div/div/div/div/div/div/span/a")).click();
		    Thread.sleep(300);
		    driver.findElement(By.linkText("AddAccount")).click();
		    driver.findElement(By.xpath(".//*[@id='FirstName']")).sendKeys("mark");
		    Thread.sleep(500);
		    driver.findElement(By.xpath(".//*[@id='LastName']")).sendKeys("johnson");
		    Thread.sleep(500);
		    driver.findElement(By.xpath(".//*[@id='AccountNo']")).sendKeys("36542");
		    Thread.sleep(500);
		    new Select(driver.findElement(By.xpath(".//*[@id='TypeOfAccount']"))).selectByVisibleText("Debit");
		    Thread.sleep(500);
		    driver.findElement(By.xpath(".//*[@id='LoanAmount']")).sendKeys("2000");
		    driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/span/button")).click();
		     Thread.sleep(500);
		    driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div[2]/div/div/span/a")).click();
		    driver.findElement(By.linkText("Log off")).click();
		    driver.close();

	}

}
