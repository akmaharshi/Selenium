package DebitAccountType;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ManagerReject {
//	WebDriver driver = new FirefoxDriver();
//	 @BeforeMethod
//	  public void beforeMethod() {
//		  
//			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//			driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
//			driver.manage().window().maximize();
//	 }		
@Test
public void TestCase4() throws InterruptedException {
	System.out.println("Testcase 4 Started");
	System.out.println("Scenario- Manager Rejection for Debit Account- Started");
	WebDriver driver = new FirefoxDriver();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get("https://172.18.0.129:8443/prweb/PRServlet/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*/!STANDARD");
	driver.manage().window().maximize();
	 driver.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys("manager@lrv");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("rules");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='sub']")).click();
		Thread.sleep(500);
		driver.findElement(By.linkText("My Work")).click();
		Thread.sleep(500);
		//driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[1]/div/div/div[5]/div/div/div/div/div/div/div/span/a")).click();
		List<WebElement> frameList;
	    frameList=driver.findElements(By.tagName("iframe"));
	    //System.out.println(frameList.size());
	    //System.out.println(driver.findElement(By.tagName("iframe")).getAttribute("id"));
	    //System.out.println(frameList.get(1).getAttribute("id"));
	    driver.switchTo().frame(frameList.get(1).getAttribute("id"));
	     driver.findElement(By.xpath("/html/body/div[3]/form/div[3]/table/tbody/tr/td/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/span/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/span/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/table/tbody/tr/td[2]/div/table/tbody/tr[2]/td[2]/div")).click();
	    driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.navigate().refresh();
	    List<WebElement> frameList2;
	    frameList2=driver.findElements(By.tagName("iframe"));
	    //System.out.println(frameList2.size());
	    //System.out.println(driver.findElement(By.tagName("iframe")).getAttribute("id"));
	    driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("id"));
	    driver.findElement(By.xpath(".//*[@id='ManagerApproval']")).click();
	    driver.findElement(By.xpath(".//*[@id='ManagerApproval']")).sendKeys("Reject");
	    driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[3]/div/div/span/button")).click();
	    System.out.println("Debit Account Rejected");
	    driver.navigate().refresh();
	    //driver.findElement(By.linkText("My Work")).click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='RULE_KEY']/div[2]/div/div/div[2]/div/div/span/a")).click();
	    driver.findElement(By.linkText("Log off")).click();
	    driver.close();
		driver.quit();
		System.out.println("Scenario- Manager Rejection for Debit Account- Ended");
		System.out.println("Testcase 4 Completed");
}
//		@AfterMethod
//public void afterMethod() {
//	  driver.close();
//	  driver.quit();
//
//
//}


}
